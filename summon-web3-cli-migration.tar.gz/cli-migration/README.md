# Summon Web3 CLI

A command-line interface for managing Summon Web3 contract deployments and interactions. This CLI tool allows you to submit contract deployments to the database, retrieve contract information, and execute function calls across multiple blockchain networks.

## Features

- 🚀 **Deploy Contracts**: Submit contract deployments to the Summon Web3 database
- 🔍 **Get Contract Info**: Retrieve contract details by name and chain ID
- ⚙️ **Execute Functions**: Batch execute function calls on deployed contracts
- 🌐 **Multi-Network**: Support for 15+ blockchain networks
- 🔒 **Secure**: Environment-based configuration for API credentials
- ✅ **Validation**: Comprehensive input validation and error handling
- 🎯 **Dry Run**: Test commands without making actual changes

## Installation

### From NPM (when published)
```bash
npm install -g summon-web3-cli
```

### From Source
```bash
git clone <repository-url>
cd summon-web3-backend
npm install
npm run build
npm link
```

## Configuration

Set up your environment variables:

```bash
# Copy the example environment file
cp env.example .env

# Edit with your values
export ACHIEVO_BASE_URL="https://your-api-endpoint.com"
export ACHIEVO_AUTH_TOKEN="your-auth-token"
export INFURA_API_KEY="your-infura-key"  # For Ethereum networks
export ALCHEMY_API_KEY="your-alchemy-key"  # For Arbitrum networks
```

## Usage

### Basic Commands

```bash
# Show help
summon-web3 --help

# Show examples
summon-web3 help-examples

# Check version
summon-web3 --version
```

### Deploy Contracts

Submit contract deployments to the database:

```bash
# Deploy from JSON file
summon-web3 deploy -f deployments.json -t Game7

# Dry run (validate without submitting)
summon-web3 deploy -f deployments.json -t Game7 --dry-run

# Verbose output
summon-web3 deploy -f deployments.json -t Game7 --verbose

# Override API settings
summon-web3 deploy -f deployments.json -t Game7 --base-url https://api.example.com --auth-token your-token
```

### Get Contract Information

Retrieve contract details from the database:

```bash
# Get contract by name
summon-web3 get-contract HelloWorld

# Get contract for specific chain
summon-web3 get-contract HelloWorld -c 1337

# Output as JSON
summon-web3 get-contract HelloWorld --json

# Verbose output
summon-web3 get-contract HelloWorld --verbose
```

### Execute Function Calls

Execute batch function calls:

```bash
# Execute from JSON file
summon-web3 execute-calls -f functions.json -t Game7

# Dry run
summon-web3 execute-calls -f functions.json -t Game7 --dry-run

# Verbose output
summon-web3 execute-calls -f functions.json -t Game7 --verbose
```

### Configuration Helper

```bash
# Get environment variable commands
summon-web3 config base-url https://api.example.com
summon-web3 config auth-token your-auth-token
```

## File Formats

### Deployment File (deployments.json)

```json
{
  "deployments": [
    {
      "contractAbi": [...],
      "contractAddress": "0x1234567890123456789012345678901234567890",
      "type": "Contract",
      "name": "HelloWorld",
      "networkName": "localhost",
      "chainId": 1337,
      "rpcUrl": "http://localhost:8545",
      "currency": "ETH",
      "blockExplorerBaseUrl": "http://localhost:8545",
      "privateKey": "0x...",
      "publicKey": "0x...",
      "paymasterAddresses": [],
      "fakeContractAddress": "0x0000000000000000000000000000000000000000",
      "explorerUrl": "http://localhost:8545/tx/...",
      "upgradable": false
    }
  ]
}
```

### Function Calls File (functions.json)

```json
{
  "calls": [
    {
      "contractName": "HelloWorld",
      "functionName": "initialize",
      "args": [42],
      "contractAddress": "0x1234567890123456789012345678901234567890"
    },
    {
      "contractName": "HelloWorld",
      "functionName": "greeting",
      "args": []
    }
  ]
}
```

## Supported Networks

The CLI supports the following blockchain networks:

| Network | Chain ID | Network Name | Currency |
|---------|----------|--------------|----------|
| Ethereum Mainnet | 1 | mainnet | ETH |
| Ethereum Sepolia | 11155111 | sepolia | ETH |
| Polygon | 137 | polygon | MATIC |
| Polygon Mumbai | 80001 | polygonMumbai | MATIC |
| Arbitrum One | 42161 | arbitrumOne | ETH |
| Arbitrum Sepolia | 421614 | arbitrumSepolia | ETH |
| Base | 8453 | base | ETH |
| Base Sepolia | 84532 | baseSepolia | ETH |
| OP Mainnet | 10 | OPMainnet | ETH |
| OP Sepolia | 11155420 | OPSepolia | ETH |
| Mantle | 5000 | mantle | MNT |
| Mantle Sepolia | 5003 | mantleSepolia | MNT |
| Linea | 59144 | linea | ETH |
| Linea Sepolia | 59141 | lineaSepolia | ETH |
| Game7 Testnet | 13746 | game7Testnet | TG7T |
| Game7 Mainnet | 2187 | game7 | G7 |

## Supported Tenants

- `Game7`
- `HyperPlay`
- `Summon`

## Error Handling

The CLI provides comprehensive error handling:

- ✅ Input validation with detailed error messages
- 🔍 Network and contract name validation
- 🚫 API error handling with status codes
- 📝 Verbose mode for debugging
- 🔄 Retry logic for transient failures

## Development

### Setup

```bash
# Install dependencies
npm install

# Run in development mode
npm run dev

# Build for production
npm run build

# Run linting
npm run lint

# Fix linting issues
npm run lint:fix

# Run tests
npm run test
```

### Project Structure

```
src/
├── commands/           # CLI command implementations
│   ├── deploy.ts      # Deploy contracts command
│   ├── get-contract.ts # Get contract info command
│   └── execute-calls.ts # Execute function calls command
├── types/             # TypeScript type definitions
│   ├── deployment.ts  # Deployment and function call types
│   ├── network.ts     # Network enums and types
│   ├── contract.ts    # Contract name enums
│   └── tenant.ts      # Tenant enum
├── config/            # Configuration modules
│   ├── api.ts        # API client setup
│   └── networks.ts   # Network configurations
├── utils/             # Utility functions
│   ├── validation.ts # Input validation
│   └── formatter.ts  # Output formatting
└── cli.ts            # Main CLI entry point
```

## Migration from Helper Functions

This CLI tool was migrated from the original helper functions in the `summon-contracts` repository. The main changes include:

- **CLI Interface**: Commands instead of function calls
- **File-based Input**: JSON files for batch operations
- **Environment Configuration**: Environment variables for security
- **Enhanced Validation**: Comprehensive input validation
- **Better Error Handling**: Detailed error messages and status codes
- **Dry Run Mode**: Safe testing without making changes

## Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/new-feature`
3. Make your changes and add tests
4. Run linting and tests: `npm run lint && npm run test`
5. Commit your changes: `git commit -am 'Add new feature'`
6. Push to the branch: `git push origin feature/new-feature`
7. Submit a pull request

## License

MIT License - see LICENSE file for details.

## Support

For issues and questions:
- Create an issue on GitHub
- Contact the Summon team
- Check the documentation and examples

---

**Happy deploying! 🚀**
