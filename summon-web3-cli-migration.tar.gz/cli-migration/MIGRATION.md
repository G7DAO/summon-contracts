# Migration Guide: From Helper Functions to CLI

This document explains how to migrate from the original helper functions in `summon-contracts` to the new CLI tool.

## Original vs New Approach

### Before (Helper Functions)
```typescript
import { submitContractDeploymentsToDB } from '@helpers/contract';
import { TENANT } from '@constants/tenant';

// In your script
await submitContractDeploymentsToDB(deployments, TENANT.Game7);
```

### After (CLI Tool)
```bash
# Create deployments.json file with your deployment data
summon-web3 deploy -f deployments.json -t Game7
```

## Key Benefits of Migration

1. **Standalone Tool**: No longer depends on the entire `summon-contracts` codebase
2. **Better Security**: Environment variables instead of hardcoded values
3. **Validation**: Comprehensive input validation before API calls
4. **Error Handling**: Better error messages and debugging
5. **Dry Run**: Test before executing
6. **Batch Operations**: Handle multiple deployments/calls efficiently

## Migration Steps

### 1. Copy the CLI to Your New Repository

```bash
# Copy the entire cli-migration folder to your new repo
cp -r cli-migration/ /path/to/summon-web3-backend/
cd /path/to/summon-web3-backend/
```

### 2. Install Dependencies

```bash
npm install
```

### 3. Build the CLI

```bash
npm run build
```

### 4. Install Globally (Optional)

```bash
npm link
# or
npm install -g .
```

### 5. Set Up Environment

```bash
# Copy environment template
cp env.example .env

# Set your environment variables
export ACHIEVO_BASE_URL="your-api-url"
export ACHIEVO_AUTH_TOKEN="your-auth-token"
```

### 6. Convert Your Deployment Data

Transform your existing deployment scripts to use JSON files:

```typescript
// Old approach - in your deploy script
const deployments = [
  {
    contractAbi: abi,
    contractAddress: address,
    // ... other fields
  }
];

await submitContractDeploymentsToDB(deployments, TENANT.Game7);
```

```json
// New approach - deployments.json
{
  "deployments": [
    {
      "contractAbi": [...],
      "contractAddress": "0x...",
      "type": "Contract",
      "name": "HelloWorld",
      "networkName": "localhost",
      "chainId": 1337,
      "rpcUrl": "http://localhost:8545",
      "currency": "ETH",
      "blockExplorerBaseUrl": "http://localhost:8545",
      "privateKey": "0x...",
      "publicKey": "0x...",
      "paymasterAddresses": [],
      "fakeContractAddress": "0x...",
      "explorerUrl": "http://localhost:8545/tx/..."
    }
  ]
}
```

### 7. Update Your Scripts

Replace your TypeScript deployment scripts with CLI commands:

```bash
# Instead of running a TypeScript script
# node deploy-script.ts

# Use the CLI
summon-web3 deploy -f deployments.json -t Game7
```

## Function Mapping

| Original Function | New CLI Command | Example |
|-------------------|-----------------|---------|
| `submitContractDeploymentsToDB` | `deploy` | `summon-web3 deploy -f deployments.json -t Game7` |
| `getContractFromDB` | `get-contract` | `summon-web3 get-contract HelloWorld -c 1337` |
| `executeFunctionCallBatch` | `execute-calls` | `summon-web3 execute-calls -f functions.json -t Game7` |

## Integration Examples

### CI/CD Pipeline

```yaml
# .github/workflows/deploy.yml
name: Deploy Contracts
on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
      
      - name: Install CLI
        run: |
          npm install -g summon-web3-cli
      
      - name: Deploy to Game7
        run: |
          summon-web3 deploy -f deployments/game7.json -t Game7
        env:
          ACHIEVO_BASE_URL: ${{ secrets.ACHIEVO_BASE_URL }}
          ACHIEVO_AUTH_TOKEN: ${{ secrets.ACHIEVO_AUTH_TOKEN }}
```

### Docker Integration

```dockerfile
FROM node:18-alpine

WORKDIR /app
COPY package*.json ./
RUN npm install -g summon-web3-cli

COPY deployments/ ./deployments/

CMD ["summon-web3", "deploy", "-f", "deployments/production.json", "-t", "Game7"]
```

### Makefile Integration

```makefile
# Makefile
.PHONY: deploy-local deploy-testnet deploy-mainnet

deploy-local:
	summon-web3 deploy -f deployments/local.json -t Game7 --verbose

deploy-testnet:
	summon-web3 deploy -f deployments/testnet.json -t Game7 --verbose

deploy-mainnet:
	summon-web3 deploy -f deployments/mainnet.json -t Game7

get-contract:
	summon-web3 get-contract $(CONTRACT_NAME) -c $(CHAIN_ID)
```

## Testing Your Migration

1. **Dry Run First**:
   ```bash
   summon-web3 deploy -f deployments.json -t Game7 --dry-run
   ```

2. **Start with Local/Testnet**:
   ```bash
   summon-web3 deploy -f deployments-local.json -t Game7 --verbose
   ```

3. **Verify Deployment**:
   ```bash
   summon-web3 get-contract HelloWorld -c 1337
   ```

## Troubleshooting

### Common Issues

1. **Authentication Error**:
   - Check `ACHIEVO_AUTH_TOKEN` environment variable
   - Verify token has proper permissions

2. **Network Error**:
   - Check `ACHIEVO_BASE_URL` environment variable
   - Ensure API endpoint is accessible

3. **Validation Error**:
   - Use `--verbose` flag for detailed error messages
   - Check JSON file format against examples

4. **Contract Not Found**:
   - Verify contract name spelling
   - Check if contract exists on specified chain ID

### Debug Mode

```bash
# Enable verbose logging
summon-web3 deploy -f deployments.json -t Game7 --verbose

# Test without making changes
summon-web3 deploy -f deployments.json -t Game7 --dry-run
```

## Backwards Compatibility

If you need to keep using the original functions temporarily:

1. Keep the original helper functions in your codebase
2. Use the CLI for new deployments
3. Gradually migrate existing scripts to use the CLI
4. Remove the original helpers once migration is complete

This approach allows for a gradual migration without breaking existing workflows.
