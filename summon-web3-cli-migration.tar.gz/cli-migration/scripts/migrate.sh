#!/bin/bash

# Migration script for Summon Web3 CLI
set -e

echo "🚀 Starting Summon Web3 CLI Migration..."

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_step() {
    echo -e "${BLUE}📋 $1${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

# Check if we're in the right directory
if [ ! -f "package.json" ]; then
    print_error "package.json not found. Please run this script from the CLI root directory."
    exit 1
fi

print_step "Installing dependencies..."
npm install
print_success "Dependencies installed"

print_step "Building TypeScript..."
npm run build
print_success "Build completed"

print_step "Running linter..."
if npm run lint; then
    print_success "Linting passed"
else
    print_warning "Linting issues found. Run 'npm run lint:fix' to auto-fix."
fi

print_step "Linking CLI globally..."
if npm link; then
    print_success "CLI linked globally as 'summon-web3'"
else
    print_warning "Global linking failed. You can still use 'npm run dev' for local testing."
fi

print_step "Setting up environment..."
if [ ! -f ".env" ]; then
    if [ -f "env.example" ]; then
        cp env.example .env
        print_warning "Created .env from example. Please update with your values:"
        echo "  - ACHIEVO_BASE_URL"
        echo "  - ACHIEVO_AUTH_TOKEN" 
        echo "  - INFURA_API_KEY (optional)"
        echo "  - ALCHEMY_API_KEY (optional)"
    else
        print_warning "No .env file found. Please create one with required environment variables."
    fi
else
    print_success "Environment file exists"
fi

print_step "Testing CLI installation..."
if command -v summon-web3 >/dev/null 2>&1; then
    echo -e "${GREEN}"
    summon-web3 --version
    echo -e "${NC}"
    print_success "CLI is working correctly"
else
    print_warning "CLI not found in PATH. Use 'npm run dev' to test locally."
fi

echo ""
print_success "Migration completed! 🎉"
echo ""
echo -e "${BLUE}Next steps:${NC}"
echo "1. Update your .env file with proper values"
echo "2. Test with: summon-web3 --help"
echo "3. Try a dry run: summon-web3 deploy -f examples/deployments.example.json -t Game7 --dry-run"
echo "4. Copy this CLI to your new repository: /summon-web3-backend"
echo ""
echo -e "${BLUE}For help:${NC}"
echo "- Run: summon-web3 help-examples"
echo "- Check: README.md"
echo "- Read: MIGRATION.md"
