import { Command } from 'commander';
import { readFileSync } from 'fs';
import { createApiClient } from '../config/api';
import { validateTenant, validateDeployments } from '../utils/validation';
import { formatSuccess, formatError, formatWarning, formatInfo } from '../utils/formatter';
import { TENANT } from '../types/tenant';
import { Deployment } from '../types/deployment';

export interface DeployOptions {
    file?: string;
    tenant?: string;
    baseUrl?: string;
    authToken?: string;
    verbose?: boolean;
    dryRun?: boolean;
}

export const deployCommand = new Command('deploy')
    .description('Submit contract deployments to database')
    .option('-f, --file <path>', 'JSON file containing deployment data')
    .option('-t, --tenant <tenant>', 'Tenant name (Game7, HyperPlay, Summon)')
    .option('--base-url <url>', 'API base URL (overrides ACHIEVO_BASE_URL)')
    .option('--auth-token <token>', 'Auth token (overrides ACHIEVO_AUTH_TOKEN)')
    .option('-v, --verbose', 'Verbose logging')
    .option('--dry-run', 'Validate input without submitting to API')
    .action(async (options: DeployOptions) => {
        try {
            await handleDeploy(options);
        } catch (error) {
            console.error(formatError(`Deploy failed: ${(error as Error).message}`));
            process.exit(1);
        }
    });

async function handleDeploy(options: DeployOptions) {
    // Validate required options
    if (!options.tenant) {
        throw new Error('Tenant is required. Use -t or --tenant option.');
    }

    if (!validateTenant(options.tenant)) {
        throw new Error(`Invalid tenant: ${options.tenant}. Must be one of: ${Object.values(TENANT).join(', ')}`);
    }

    // Load deployments
    let deployments: Deployment[];
    
    if (options.file) {
        if (options.verbose) {
            console.log(formatInfo(`Loading deployments from file: ${options.file}`));
        }
        deployments = loadDeploymentsFromFile(options.file);
    } else {
        throw new Error('No deployment data provided. Use -f or --file option to specify a JSON file.');
    }

    // Validate deployments
    const validationErrors = validateDeployments(deployments);
    if (validationErrors.length > 0) {
        console.error(formatError('Validation errors:'));
        validationErrors.forEach(error => console.error(`  - ${error}`));
        throw new Error('Deployment validation failed');
    }

    if (options.verbose) {
        console.log(formatInfo(`Found ${deployments.length} deployment(s) to submit`));
        deployments.forEach((deployment, index) => {
            console.log(`  ${index + 1}. ${deployment.name} on ${deployment.networkName}`);
        });
    }

    // Dry run check
    if (options.dryRun) {
        console.log(formatWarning('Dry run mode - no data will be submitted'));
        console.log(formatSuccess('Validation completed successfully'));
        return;
    }

    // Submit deployments
    await submitDeployments(deployments, options.tenant as TENANT, options);
}

function loadDeploymentsFromFile(filePath: string): Deployment[] {
    try {
        const fileContent = readFileSync(filePath, 'utf-8');
        const data = JSON.parse(fileContent);
        
        // Handle both array format and object with deployments property
        if (Array.isArray(data)) {
            return data;
        } else if (data.deployments && Array.isArray(data.deployments)) {
            return data.deployments;
        } else {
            throw new Error('File must contain an array of deployments or an object with a "deployments" property');
        }
    } catch (error) {
        if ((error as any).code === 'ENOENT') {
            throw new Error(`File not found: ${filePath}`);
        } else if (error instanceof SyntaxError) {
            throw new Error(`Invalid JSON in file: ${filePath}`);
        } else {
            throw error;
        }
    }
}

async function submitDeployments(deployments: Deployment[], tenant: TENANT, options: DeployOptions) {
    const apiClient = createApiClient({
        baseUrl: options.baseUrl,
        authToken: options.authToken
    });

    console.log(formatInfo(`Submitting ${deployments.length} deployment(s) to ${tenant}...`));

    // Add blockchainType to each deployment
    const deploymentsWithType = deployments.map(deployment => ({
        ...deployment,
        blockchainType: 'EVM',
    }));

    let successCount = 0;
    let errorCount = 0;

    for (const [index, deployment] of deploymentsWithType.entries()) {
        try {
            if (options.verbose) {
                console.log(formatInfo(`Submitting ${index + 1}/${deployments.length}: ${deployment.name}`));
            }

            await apiClient.post('/v2/tenant-contracts', {
                deployments: [deployment],
                tenant,
            });

            console.log(formatSuccess(`Submitted: ${deployment.name}`));
            successCount++;
        } catch (error) {
            console.error(formatError(`Failed to submit ${deployment.name}: ${(error as Error).message}`));
            errorCount++;
            
            if (options.verbose && (error as any).response) {
                console.error(formatError(`  Status: ${(error as any).response.status}`));
                console.error(formatError(`  Response: ${JSON.stringify((error as any).response.data)}`));
            }
        }
    }

    console.log('\n' + formatInfo('Summary:'));
    console.log(`  ${formatSuccess(`Successful: ${successCount}`)}`);
    if (errorCount > 0) {
        console.log(`  ${formatError(`Failed: ${errorCount}`)}`);
    }

    if (errorCount > 0) {
        throw new Error(`${errorCount} deployment(s) failed`);
    }
}
