import { Command } from 'commander';
import { readFileSync } from 'fs';
import { createApiClient } from '../config/api';
import { validateTenant } from '../utils/validation';
import { formatSuccess, formatError, formatWarning, formatInfo } from '../utils/formatter';
import { TENANT } from '../types/tenant';
import { FunctionCall } from '../types/deployment';

export interface ExecuteCallsOptions {
    file?: string;
    tenant?: string;
    baseUrl?: string;
    authToken?: string;
    verbose?: boolean;
    dryRun?: boolean;
}

export const executeCallsCommand = new Command('execute-calls')
    .description('Execute function calls batch')
    .option('-f, --file <path>', 'JSON file containing function calls')
    .option('-t, --tenant <tenant>', 'Tenant name (Game7, HyperPlay, Summon)')
    .option('--base-url <url>', 'API base URL (overrides ACHIEVO_BASE_URL)')
    .option('--auth-token <token>', 'Auth token (overrides ACHIEVO_AUTH_TOKEN)')
    .option('-v, --verbose', 'Verbose logging')
    .option('--dry-run', 'Validate input without executing calls')
    .action(async (options: ExecuteCallsOptions) => {
        try {
            await handleExecuteCalls(options);
        } catch (error) {
            console.error(formatError(`Execute calls failed: ${(error as Error).message}`));
            process.exit(1);
        }
    });

async function handleExecuteCalls(options: ExecuteCallsOptions) {
    // Validate required options
    if (!options.tenant) {
        throw new Error('Tenant is required. Use -t or --tenant option.');
    }

    if (!validateTenant(options.tenant)) {
        throw new Error(`Invalid tenant: ${options.tenant}. Must be one of: ${Object.values(TENANT).join(', ')}`);
    }

    // Load function calls
    let functionCalls: FunctionCall[];
    
    if (options.file) {
        if (options.verbose) {
            console.log(formatInfo(`Loading function calls from file: ${options.file}`));
        }
        functionCalls = loadFunctionCallsFromFile(options.file);
    } else {
        throw new Error('No function calls provided. Use -f or --file option to specify a JSON file.');
    }

    // Validate function calls
    const validationErrors = validateFunctionCalls(functionCalls);
    if (validationErrors.length > 0) {
        console.error(formatError('Validation errors:'));
        validationErrors.forEach(error => console.error(`  - ${error}`));
        throw new Error('Function calls validation failed');
    }

    if (options.verbose) {
        console.log(formatInfo(`Found ${functionCalls.length} function call(s) to execute`));
        functionCalls.forEach((call, index) => {
            console.log(`  ${index + 1}. ${call.contractName}.${call.functionName}()`);
        });
    }

    // Dry run check
    if (options.dryRun) {
        console.log(formatWarning('Dry run mode - no calls will be executed'));
        console.log(formatSuccess('Validation completed successfully'));
        return;
    }

    // Execute function calls
    await executeFunctionCalls(functionCalls, options.tenant as TENANT, options);
}

function loadFunctionCallsFromFile(filePath: string): FunctionCall[] {
    try {
        const fileContent = readFileSync(filePath, 'utf-8');
        const data = JSON.parse(fileContent);
        
        // Handle both array format and object with calls property
        if (Array.isArray(data)) {
            return data;
        } else if (data.calls && Array.isArray(data.calls)) {
            return data.calls;
        } else {
            throw new Error('File must contain an array of function calls or an object with a "calls" property');
        }
    } catch (error) {
        if ((error as any).code === 'ENOENT') {
            throw new Error(`File not found: ${filePath}`);
        } else if (error instanceof SyntaxError) {
            throw new Error(`Invalid JSON in file: ${filePath}`);
        } else {
            throw error;
        }
    }
}

function validateFunctionCalls(calls: any[]): string[] {
    const errors: string[] = [];

    if (!Array.isArray(calls)) {
        errors.push('Function calls must be an array');
        return errors;
    }

    calls.forEach((call, index) => {
        if (!call.contractName) {
            errors.push(`Function call at index ${index} is missing contractName`);
        }
        if (!call.functionName) {
            errors.push(`Function call at index ${index} is missing functionName`);
        }
        if (!Array.isArray(call.args)) {
            errors.push(`Function call at index ${index} args must be an array`);
        }
    });

    return errors;
}

async function executeFunctionCalls(calls: FunctionCall[], tenant: TENANT, options: ExecuteCallsOptions) {
    const apiClient = createApiClient({
        baseUrl: options.baseUrl,
        authToken: options.authToken
    });

    console.log(formatInfo(`Executing ${calls.length} function call(s) for ${tenant}...`));

    try {
        await apiClient.post('/v2/tenant-contracts/functions', {
            calls,
            tenant,
        });

        console.log(formatSuccess(`Successfully executed ${calls.length} function call(s)`));
    } catch (error) {
        if (options.verbose && (error as any).response) {
            console.error(formatError(`Status: ${(error as any).response.status}`));
            console.error(formatError(`Response: ${JSON.stringify((error as any).response.data)}`));
        }
        throw error;
    }
}
