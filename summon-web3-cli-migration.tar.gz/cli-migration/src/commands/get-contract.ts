import { Command } from 'commander';
import { createApiClient } from '../config/api';
import { validateContractName } from '../utils/validation';
import { formatSuccess, formatError, formatInfo, formatDeployment } from '../utils/formatter';
import { CONTRACT_NAME, CONTRACT_PROXY_CONTRACT_NAME } from '../types/contract';
import { Deployment } from '../types/deployment';

export interface GetContractOptions {
    chainId?: number;
    baseUrl?: string;
    authToken?: string;
    verbose?: boolean;
    json?: boolean;
}

export const getContractCommand = new Command('get-contract')
    .description('Get contract details from database')
    .argument('<name>', 'Contract name')
    .option('-c, --chain-id <id>', 'Chain ID filter', parseInt)
    .option('--base-url <url>', 'API base URL (overrides ACHIEVO_BASE_URL)')
    .option('--auth-token <token>', 'Auth token (overrides ACHIEVO_AUTH_TOKEN)')
    .option('-v, --verbose', 'Verbose logging')
    .option('--json', 'Output as JSON')
    .action(async (name: string, options: GetContractOptions) => {
        try {
            await handleGetContract(name, options);
        } catch (error) {
            console.error(formatError(`Get contract failed: ${(error as Error).message}`));
            process.exit(1);
        }
    });

async function handleGetContract(name: string, options: GetContractOptions) {
    // Validate contract name
    if (!validateContractName(name)) {
        const validNames = [
            ...Object.values(CONTRACT_NAME),
            ...Object.values(CONTRACT_PROXY_CONTRACT_NAME)
        ];
        throw new Error(`Invalid contract name: ${name}. Must be one of: ${validNames.join(', ')}`);
    }

    // Get contract from API
    const deployment = await fetchContract(name as CONTRACT_NAME | CONTRACT_PROXY_CONTRACT_NAME, options);

    if (!deployment) {
        console.log(formatInfo(`No contract found with name: ${name}${options.chainId ? ` on chain ${options.chainId}` : ''}`));
        return;
    }

    // Output result
    if (options.json) {
        console.log(JSON.stringify(deployment, null, 2));
    } else {
        console.log(formatSuccess('Contract found:'));
        console.log(formatDeployment(deployment));
    }
}

async function fetchContract(
    name: CONTRACT_NAME | CONTRACT_PROXY_CONTRACT_NAME,
    options: GetContractOptions
): Promise<Deployment | undefined> {
    const apiClient = createApiClient({
        baseUrl: options.baseUrl,
        authToken: options.authToken
    });

    if (options.verbose) {
        console.log(formatInfo(`Fetching contract: ${name}${options.chainId ? ` (Chain ID: ${options.chainId})` : ''}`));
    }

    try {
        const queryParams = options.chainId ? `?chainId=${options.chainId}` : '';
        const { data } = await apiClient.get(`/v2/tenant-contracts/${name}${queryParams}`);
        
        if (data.status === 200) {
            return data.data;
        } else {
            if (options.verbose) {
                console.log(formatInfo(`API returned status: ${data.status}`));
            }
            return undefined;
        }
    } catch (error) {
        if ((error as any).response?.status === 404) {
            return undefined;
        }
        throw error;
    }
}
