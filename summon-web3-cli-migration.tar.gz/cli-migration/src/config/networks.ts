import { ChainId, NetworkName } from '../types/network';

export const rpcUrls = {
    [ChainId.Ganache]: 'http://localhost:8545',
    [ChainId.Ethereum]: `https://mainnet.infura.io/v3/${process.env.INFURA_API_KEY}`,
    [ChainId.Goerli]: `https://goerli.infura.io/v3/${process.env.INFURA_API_KEY}`,
    [ChainId.Sepolia]: `https://sepolia.infura.io/v3/${process.env.INFURA_API_KEY}`,
    [ChainId.Polygon]: 'https://polygon.llamarpc.com',
    [ChainId.PolygonMumbai]: 'https://rpc.ankr.com/polygon_mumbai',
    [ChainId.Mantle]: 'https://rpc.mantle.xyz',
    [ChainId.MantleSepolia]: 'https://rpc.sepolia.mantle.xyz',
    [ChainId.ArbitrumOne]: `https://arb-mainnet.g.alchemy.com/v2/${process.env.ALCHEMY_API_KEY}`,
    [ChainId.ArbitrumSepolia]: `https://arb-sepolia.g.alchemy.com/v2/${process.env.ALCHEMY_API_KEY}`,
    [ChainId.OPMainnet]: 'https://mainnet.optimism.io',
    [ChainId.OPSepolia]: 'https://sepolia.optimism.io',
    [ChainId.Base]: 'https://mainnet.base.org',
    [ChainId.BaseSepolia]: 'https://sepolia.base.org',
    [ChainId.Game7Testnet]: 'https://testnet-rpc.game7.io',
    [ChainId.Game7]: 'https://mainnet-rpc.game7.io',
    [ChainId.Linea]: 'https://rpc.linea.build',
    [ChainId.LineaSepolia]: 'https://rpc.sepolia.linea.build',
};

export const chainIdToNetworkName: Record<number, NetworkName> = {
    [ChainId.Ganache]: NetworkName.Ganache,
    [ChainId.Ethereum]: NetworkName.Ethereum,
    [ChainId.Goerli]: NetworkName.Goerli,
    [ChainId.Sepolia]: NetworkName.Sepolia,
    [ChainId.Polygon]: NetworkName.Polygon,
    [ChainId.PolygonMumbai]: NetworkName.PolygonMumbai,
    [ChainId.Mantle]: NetworkName.Mantle,
    [ChainId.MantleSepolia]: NetworkName.MantleSepolia,
    [ChainId.ArbitrumOne]: NetworkName.ArbitrumOne,
    [ChainId.ArbitrumSepolia]: NetworkName.ArbitrumSepolia,
    [ChainId.OPMainnet]: NetworkName.OPMainnet,
    [ChainId.OPSepolia]: NetworkName.OPSepolia,
    [ChainId.Base]: NetworkName.Base,
    [ChainId.BaseSepolia]: NetworkName.BaseSepolia,
    [ChainId.Game7Testnet]: NetworkName.Game7Testnet,
    [ChainId.Game7]: NetworkName.Game7,
    [ChainId.Linea]: NetworkName.Linea,
    [ChainId.LineaSepolia]: NetworkName.LineaSepolia,
};

export function getNetworkName(chainId: number): NetworkName {
    const networkName = chainIdToNetworkName[chainId];
    if (!networkName) {
        throw new Error(`Unsupported chain ID: ${chainId}`);
    }
    return networkName;
}

export function getRpcUrl(chainId: number): string {
    const rpcUrl = rpcUrls[chainId as keyof typeof rpcUrls];
    if (!rpcUrl) {
        throw new Error(`No RPC URL configured for chain ID: ${chainId}`);
    }
    return rpcUrl;
}
