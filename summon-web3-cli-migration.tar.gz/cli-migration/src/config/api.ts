import axios, { AxiosInstance } from 'axios';

export interface ApiConfig {
    baseUrl: string;
    authToken: string;
}

export class ApiClient {
    private client: AxiosInstance;

    constructor(config: ApiConfig) {
        this.client = axios.create({
            baseURL: config.baseUrl,
            headers: {
                'Authorization': config.authToken,
                'Content-Type': 'application/json',
            },
        });
    }

    async post(url: string, data: any) {
        return this.client.post(url, data);
    }

    async get(url: string) {
        return this.client.get(url);
    }
}

export function createApiClient(config?: Partial<ApiConfig>): ApiClient {
    const baseUrl = config?.baseUrl || process.env.ACHIEVO_BASE_URL;
    const authToken = config?.authToken || process.env.ACHIEVO_AUTH_TOKEN;

    if (!baseUrl) {
        throw new Error('ACHIEVO_BASE_URL is required. Set it via environment variable or config.');
    }

    if (!authToken) {
        throw new Error('ACHIEVO_AUTH_TOKEN is required. Set it via environment variable or config.');
    }

    return new ApiClient({
        baseUrl,
        authToken,
    });
}
