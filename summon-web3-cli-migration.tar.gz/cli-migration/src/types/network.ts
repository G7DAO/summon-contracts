export enum NETWORK_TYPE {
    MAINNET = 'MAINNET',
    TESTNET = 'TESTNET',
}

export enum ChainId {
    Ganache = 1337,
    Polygon = 137,
    PolygonMumbai = 80001,
    Mantle = 5000,
    MantleSepolia = 5003,
    Ethereum = 1,
    Goerli = 5,
    Sepolia = 11155111,
    ArbitrumOne = 42161,
    ArbitrumSepolia = 421614,
    OPMainnet = 10,
    OPSepolia = 11155420,
    Base = 8453,
    BaseSepolia = 84532,
    Game7Testnet = 13746,
    Game7 = 2187,
    Linea = 59144,
    LineaSepolia = 59141,
}

export enum NetworkName {
    Localhost = 'localhost',
    Ganache = 'ganache',
    Polygon = 'polygon',
    PolygonMumbai = 'polygonMumbai',
    Ethereum = 'mainnet',
    Goerli = 'goerli',
    Sepolia = 'sepolia',
    Mantle = 'mantle',
    MantleSepolia = 'mantleSepolia',
    ArbitrumOne = 'arbitrumOne',
    ArbitrumSepolia = 'arbitrumSepolia',
    OPMainnet = 'OPMainnet',
    OPSepolia = 'OPSepolia',
    Base = 'base',
    BaseSepolia = 'baseSepolia',
    Game7Testnet = 'game7Testnet',
    Game7 = 'game7',
    LineaSepolia = 'lineaSepolia',
    Linea = 'linea',
}

export enum Currency {
    Localhost = 'ETH',
    Ganache = 'ETH',
    Polygon = 'MATIC',
    PolygonMumbai = 'MATIC',
    Ethereum = 'ETH',
    Goerli = 'ETH',
    Sepolia = 'ETH',
    Mantle = 'MNT',
    MantleSepolia = 'MNT',
    ArbitrumOne = 'ETH',
    ArbitrumSepolia = 'ETH',
    OPMainnet = 'ETH',
    OPSepolia = 'ETH',
    Base = 'ETH',
    BaseSepolia = 'ETH',
    Game7Testnet = 'TG7T',
    Game7 = 'G7',
    Linea = 'ETH',
    LineaSepolia = 'ETH',
}

export enum NetworkExplorer {
    Localhost = 'http://localhost:8545',
    Ganache = 'http://localhost:7545',
    Polygon = 'https://polygonscan.com',
    PolygonMumbai = 'https://mumbai.polygonscan.com',
    Ethereum = 'https://etherscan.io',
    Goerli = 'https://goerli.etherscan.io',
    Sepolia = 'https://sepolia.etherscan.io',
    Mantle = 'https://explorer.mantle.xyz',
    MantleSepolia = 'https://explorer.sepolia.mantle.xyz',
    ArbitrumOne = 'https://arbitrum.blockscout.com',
    ArbitrumSepolia = 'https://arbitrum-sepolia.blockscout.com',
    OPMainnet = 'https://optimistic.etherscan.io',
    OPSepolia = 'https://sepolia-optimistic.etherscan.io',
    Base = 'https://basescan.org',
    BaseSepolia = 'https://base-sepolia.blockscout.com',
    Game7Testnet = 'https://testnet.game7.io',
    Game7 = 'https://mainnet.game7.io',
    Linea = 'https://api.lineascan.build',
    LineaSepolia = 'https://api.sepolia.lineascan.build',
}

export function getTransactionUrl(txHash: string, network: NetworkName): string {
    const explorerUrl = NetworkExplorer[network as unknown as keyof typeof NetworkExplorer];

    if (!explorerUrl) throw new Error(`Unsupported network: ${network}`);

    return `${explorerUrl}/tx/${txHash}`;
}
