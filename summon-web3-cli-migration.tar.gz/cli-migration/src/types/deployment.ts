import { NetworkName } from './network';
import { CONTRACT_NAME, CONTRACT_PROXY_CONTRACT_NAME } from './contract';
import { TENANT } from './tenant';

export interface Deployment {
    contractAbi: any;
    contractAddress: string;
    type: string;
    name: string;
    networkName: NetworkName;
    chainId: number;
    rpcUrl: string;
    currency: string;
    blockExplorerBaseUrl: string;
    privateKey: string;
    publicKey: string;
    paymasterAddresses: string[];
    fakeContractAddress: string;
    explorerUrl: string;
    salt?: string;
    upgradable?: boolean;
    proxyType?: string;
    proxy?: {
        abi: any;
        address: string;
        owner: string;
    };
    proxyAdmin?: {
        abi: any;
        address: string;
        owner: string;
    };
    implementation?: {
        abi: any;
        address: string;
    };
    extensions?: {
        abi: any;
        address: string;
        functions: any[];
        name: string;
    }[];
    createdAt?: number;
}

export interface FunctionCall {
    contractName: string;
    functionName: string;
    args: (string | number | boolean | Record<string, any>)[];
    contractAddress?: string;
}

export interface DeploymentInput {
    deployments: Deployment[];
    tenant: TENANT;
}

export interface FunctionCallInput {
    calls: FunctionCall[];
    tenant: TENANT;
}

export interface GetContractInput {
    name: CONTRACT_NAME | CONTRACT_PROXY_CONTRACT_NAME;
    chainId?: number;
}
