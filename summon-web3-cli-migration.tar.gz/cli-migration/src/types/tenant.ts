export enum TENANT {
    Game7 = 'Game7',
    HyperPlay = 'HyperPlay',
    Summon = 'Summon',
}
