#!/usr/bin/env node

import { Command } from 'commander';
import { deployCommand } from './commands/deploy';
import { getContractCommand } from './commands/get-contract';
import { executeCallsCommand } from './commands/execute-calls';
import { formatInfo } from './utils/formatter';

const program = new Command();

program
    .name('summon-web3')
    .description('CLI for Summon Web3 contract management')
    .version('1.0.0');

// Add commands
program.addCommand(deployCommand);
program.addCommand(getContractCommand);
program.addCommand(executeCallsCommand);

// Config command for setting up environment
const configCommand = new Command('config')
    .description('Configure CLI settings')
    .argument('<key>', 'Configuration key (base-url, auth-token)')
    .argument('<value>', 'Configuration value')
    .action((key: string, value: string) => {
        console.log(formatInfo(`To set ${key}, export the following environment variable:`));
        
        switch (key) {
            case 'base-url':
                console.log(`export ACHIEVO_BASE_URL="${value}"`);
                break;
            case 'auth-token':
                console.log(`export ACHIEVO_AUTH_TOKEN="${value}"`);
                break;
            default:
                console.error(`Unknown configuration key: ${key}`);
                console.error('Valid keys: base-url, auth-token');
                process.exit(1);
        }
    });

program.addCommand(configCommand);

// Help command with examples
const helpCommand = new Command('help-examples')
    .description('Show usage examples')
    .action(() => {
        console.log(`
${formatInfo('Summon Web3 CLI Usage Examples:')}

${formatInfo('Deploy contracts:')}
  summon-web3 deploy -f deployments.json -t Game7
  summon-web3 deploy -f deployments.json -t Game7 --dry-run
  summon-web3 deploy -f deployments.json -t Game7 --verbose

${formatInfo('Get contract details:')}
  summon-web3 get-contract HelloWorld
  summon-web3 get-contract HelloWorld -c 1337
  summon-web3 get-contract HelloWorld --json

${formatInfo('Execute function calls:')}
  summon-web3 execute-calls -f functions.json -t Game7
  summon-web3 execute-calls -f functions.json -t Game7 --dry-run

${formatInfo('Configuration:')}
  summon-web3 config base-url https://api.example.com
  summon-web3 config auth-token your-auth-token

${formatInfo('Environment Variables:')}
  ACHIEVO_BASE_URL    - API base URL
  ACHIEVO_AUTH_TOKEN  - Authentication token
  INFURA_API_KEY      - For Ethereum networks
  ALCHEMY_API_KEY     - For Arbitrum networks

${formatInfo('Example deployment file (deployments.json):')}
{
  "deployments": [
    {
      "contractAbi": [...],
      "contractAddress": "0x...",
      "type": "Contract",
      "name": "HelloWorld",
      "networkName": "localhost",
      "chainId": 1337,
      "rpcUrl": "http://localhost:8545",
      "currency": "ETH",
      "blockExplorerBaseUrl": "http://localhost:8545",
      "privateKey": "0x...",
      "publicKey": "0x...",
      "paymasterAddresses": [],
      "fakeContractAddress": "0x...",
      "explorerUrl": "http://localhost:8545/tx/..."
    }
  ]
}

${formatInfo('Example function calls file (functions.json):')}
{
  "calls": [
    {
      "contractName": "HelloWorld",
      "functionName": "initialize",
      "args": [123],
      "contractAddress": "0x..."
    }
  ]
}
        `);
    });

program.addCommand(helpCommand);

// Handle unknown commands
program.on('command:*', () => {
    console.error(`Unknown command: ${program.args.join(' ')}`);
    console.error('Use --help to see available commands');
    process.exit(1);
});

// Parse command line arguments
program.parse();

// Show help if no command provided
if (!process.argv.slice(2).length) {
    program.outputHelp();
}
