import { TENANT } from '../types/tenant';
import { CONTRACT_NAME, CONTRACT_PROXY_CONTRACT_NAME } from '../types/contract';
import { ChainId } from '../types/network';
import { Deployment } from '../types/deployment';

export function validateTenant(tenant: string): tenant is TENANT {
    return Object.values(TENANT).includes(tenant as TENANT);
}

export function validateContractName(name: string): name is CONTRACT_NAME | CONTRACT_PROXY_CONTRACT_NAME {
    return Object.values(CONTRACT_NAME).includes(name as CONTRACT_NAME) ||
           Object.values(CONTRACT_PROXY_CONTRACT_NAME).includes(name as CONTRACT_PROXY_CONTRACT_NAME);
}

export function validateChainId(chainId: number): chainId is ChainId {
    return Object.values(ChainId).includes(chainId as ChainId);
}

export function validateDeployment(deployment: any): deployment is Deployment {
    const required = [
        'contractAbi',
        'contractAddress',
        'type',
        'name',
        'networkName',
        'chainId',
        'rpcUrl',
        'currency',
        'blockExplorerBaseUrl',
        'privateKey',
        'publicKey',
        'paymasterAddresses',
        'fakeContractAddress',
        'explorerUrl'
    ];

    return required.every(field => deployment.hasOwnProperty(field));
}

export function validateDeployments(deployments: any[]): string[] {
    const errors: string[] = [];

    if (!Array.isArray(deployments)) {
        errors.push('Deployments must be an array');
        return errors;
    }

    deployments.forEach((deployment, index) => {
        if (!validateDeployment(deployment)) {
            errors.push(`Deployment at index ${index} is missing required fields`);
        }

        if (deployment.chainId && !validateChainId(deployment.chainId)) {
            errors.push(`Invalid chain ID at index ${index}: ${deployment.chainId}`);
        }
    });

    return errors;
}
