import { Deployment } from '../types/deployment';

export function formatDeployment(deployment: Deployment): string {
    return `
Contract: ${deployment.name}
Address: ${deployment.contractAddress}
Network: ${deployment.networkName} (Chain ID: ${deployment.chainId})
Type: ${deployment.type}
Explorer: ${deployment.explorerUrl}
${deployment.upgradable ? 'Upgradable: Yes' : ''}
${deployment.proxy ? `Proxy: ${deployment.proxy.address}` : ''}
`.trim();
}

export function formatSuccess(message: string): string {
    return `✅ ${message}`;
}

export function formatError(message: string): string {
    return `❌ ${message}`;
}

export function formatWarning(message: string): string {
    return `⚠️  ${message}`;
}

export function formatInfo(message: string): string {
    return `ℹ️  ${message}`;
}

export function formatTable(data: Record<string, string>[]): string {
    if (data.length === 0) return 'No data to display';

    const headers = Object.keys(data[0]);
    const maxWidths = headers.map(header => 
        Math.max(header.length, ...data.map(row => String(row[header] || '').length))
    );

    const separator = maxWidths.map(width => '-'.repeat(width)).join(' | ');
    const headerRow = headers.map((header, i) => header.padEnd(maxWidths[i])).join(' | ');
    
    const rows = data.map(row => 
        headers.map((header, i) => String(row[header] || '').padEnd(maxWidths[i])).join(' | ')
    );

    return [headerRow, separator, ...rows].join('\n');
}
